# Fantastic-Encoder
```
A multi-functional video encoder programmed in python.
```
