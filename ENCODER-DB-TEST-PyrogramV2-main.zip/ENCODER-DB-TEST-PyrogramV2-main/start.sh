gunicorn app:app & python3 -m SmartEncoder







