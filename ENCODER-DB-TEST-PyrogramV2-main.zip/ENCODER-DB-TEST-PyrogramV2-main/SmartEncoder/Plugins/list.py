# list.py>
"""
Python3 --> list
"""

#from SmartEncoder.Database.db import myDB

crf = []
crf.append("33.5")
codec = []
codec.append("libx264")
qualityy = []
qualityy.append("846x480")
audio_codec = []
audio_codec.append("libopus")
audio_ = []
audio_.append("32k")
#myDB.set('crf', "29.5")
#video.codec.append("libx265")
#video.quality.append("852x480")

#class audio:
 # a_bitrate = []
 # a_codec = []

#audio.a_bitrate.append("45k")
#audio.a_codec.append("libopus")

preset = []
preset.append("fast")

#speed.preset.append("fast")

class watermark:
  size_one = []
  size_two = []

watermark_size = []
watermark_size.append("25")
watermark.size_one.append('25')
watermark.size_two.append('30')
vanish = []
vanish.insert(0, "true")
#class queue:
data = []
queue = []
name = []
name.append("480p")
pdfiles = []
audiofiles = []
rename_queue = []
rename_task = []
rename_task.insert(0, "off")

quality_ = []
